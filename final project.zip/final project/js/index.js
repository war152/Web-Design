function toggleMode() {
  var body = document.getElementById("body");
  var currentClass = body.className;
  body.className = currentClass == "light" ? "dark" : "light";
  
  
  var nav = document.getElementById("navbar");
  var currentClass3 = nav.className;
  nav.className = currentClass3 == "light" ? "dark" : "light";
  

}